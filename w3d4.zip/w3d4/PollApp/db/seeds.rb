# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)


u1 = User.create(:user_name => "Elif")
u2 = User.create(:user_name => "Nate")

p1 = Poll.create(:title => "Hungry", :author_id => u1.id)
p2 = Poll.create(:title => "", :author_id => u2.id)

q1 = Question.create(:poll_id => p1.id, :text => "Are you hungry?")
q2 = Question.create(:poll_id => p1.id, :text => "Are you thirsty?")

a1 = AnswerChoice.create(:question_id => q1.id, text: "Yes")
a2 = AnswerChoice.create(:question_id => q1.id, text: "No")
a3 = AnswerChoice.create(:question_id => q2.id, text: "Yes")
a4 = AnswerChoice.create(:question_id => q2.id, text: "No")

r1 = Response.create(:user_id => u2.id, :answer_choice_id => a1.id)
r2 = Response.create(:user_id => u1.id, :answer_choice_id => a2.id)
r3 = Response.create(:user_id => u2.id, :answer_choice_id => a3.id)
r4 = Response.create(:user_id => u1.id, :answer_choice_id => a4.id)
